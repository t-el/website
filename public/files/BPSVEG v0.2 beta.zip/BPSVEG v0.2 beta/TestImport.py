def Chak_import(string : str):
    
    if "import" in string and not("from" in string):
        Iimp = string.replace("import","").replace(" ","")
        
    elif "import" in string and "from" in string:
        Temp = string.replace("import","").replace("from","")
        Temp = Temp.split(" ")
        
        Iimp = Temp[1]
        Simp = Temp[3]
        
    
    try:
        exec(string)
        text = True
        
    
    except ModuleNotFoundError as e:
        text = "ModuleNotFoundError: " + str(e)
        
    
    except ImportError as e:
    
        text = "ImportError: " + str(e)
        

    except SyntaxError:
        text = "SyntaxError: invalid syntax"

    except NameError as e:
        text = "NameError: "+ str(e)

    return text

import sys as saaaaaaaaaaadooooooooooooossssssssssy
_import = saaaaaaaaaaadooooooooooooossssssssssy.argv[1]
res = Chak_import(_import)
print(res)

with open("resTestImport.txt","w") as op:
    op.write(str(res))
