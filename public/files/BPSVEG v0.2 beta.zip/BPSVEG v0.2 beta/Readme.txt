You must use a program with these conditions or it will not work and errors will occur:

1. The presence of a Python environment in your computer .. any version of 3 and above
2. Install the following libraries:
pip install cryptography
pip install pyinstaller

3. Configure the path setting for Python. The following commands should run when typing in cmd:
python
pyinstaller
pip